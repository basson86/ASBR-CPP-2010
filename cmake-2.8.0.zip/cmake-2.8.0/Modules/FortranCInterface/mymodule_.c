/* PGI Fortran wants mymodule_ when calling any mymodule symbol.  */
void mymodule_(void) {}
