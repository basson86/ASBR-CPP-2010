/* PGI Fortran wants my_module_ when calling any my_module symbol.  */
void my_module_(void) {}
